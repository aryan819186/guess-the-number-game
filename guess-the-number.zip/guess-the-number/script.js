let target = Math.floor(Math.random() * 1000) + 1;
let chances = 0;

const clickSound = document.getElementById("clickSound");
const winSound = document.getElementById("winSound");
const wrongSound = document.getElementById("wrongSound");
const hintSound = document.getElementById("hintSound");

function handleGuess() {
  const inputBox = document.getElementById("inputBox");
  const log = document.getElementById("log");

  if (inputBox.disabled) return;

  const input = inputBox.value.trim();
  inputBox.value = "";
  if (!input) return;

  chances++;
  clickSound.currentTime = 0;
  clickSound.play();

  if (input.toLowerCase() === "q" || input.toLowerCase() === "quit") {
    wrongSound.play();
    logMessage(`Game ended! The correct number was ${target}.\n\n-------> GAME OVER <-------\n-----------😈-----------\n`);
    disableInput();
    addRestartButton();
    return;
  }

  if (input.toLowerCase() === "h") {
    hintSound.play();
    let hint = Math.floor(target / 100) * 100;
    logMessage(`Hint: The number is between ${hint} and ${hint + 100}\n`);
    return;
  }

  const guess = parseInt(input, 10);
  if (isNaN(guess)) {
    logMessage("⚠️ Please enter a valid number!\n");
    return;
  }

  logMessage(`Attempt ${chances}: You guessed ${guess}.`);

  if (guess === target) {
    winSound.play();
    logMessage(`🎉🎉 You win! 🎉🎉\nYou guessed it in ${chances} attempts!\nCorrect number: ${target}\n`);
    disableInput();
    addRestartButton();
  } else if (Math.abs(guess - target) < 10) {
    wrongSound.play();
    logMessage(`🔥 Almost! Try a bit ${guess > target ? "smaller" : "bigger"}.\n`);
  } else {
    wrongSound.play();
    logMessage(`📉 Your guess is too ${guess > target ? "high" : "low"}.\n`);
  }
}

function disableInput() {
  document.getElementById("inputBox").disabled = true;
}

function logMessage(message) {
  const log = document.getElementById("log");
  log.innerText += `${message}\n`;
  log.scrollTop = log.scrollHeight;
}

function addRestartButton() {
  const container = document.getElementById("restartContainer");
  container.innerHTML = `<button onclick="restartGame()">🔁 Restart Game</button>`;
}

function restartGame() {
  target = Math.floor(Math.random() * 1000) + 1;
  chances = 0;
  document.getElementById("log").innerText = "Game restarted! Enter a number, H for Hint, or Q to Quit.\n";
  document.getElementById("inputBox").disabled = false;
  document.getElementById("restartContainer").innerHTML = "";
  document.getElementById("inputBox").focus();
}
